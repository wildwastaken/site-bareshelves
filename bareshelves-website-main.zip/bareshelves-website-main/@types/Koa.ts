export interface KoaState {
  // loggedIn?: boolean
  // userId?: string
  limit?: number
  filter?: Record<string, unknown>
  sort?: Record<string, unknown>
}
