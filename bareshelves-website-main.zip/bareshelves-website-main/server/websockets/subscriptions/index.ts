import {
  stock,
} from './stock'

export const subscriptions = [
  stock,
]
