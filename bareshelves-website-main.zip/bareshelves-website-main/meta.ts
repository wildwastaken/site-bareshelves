export const meta = {
  title: 'BareShelves',
  description: 'Lorem ipsum dolor sit amet.',
  thumbnail: 'example.webp',
  themeColor: '',
  url: 'https://example.com',
}
